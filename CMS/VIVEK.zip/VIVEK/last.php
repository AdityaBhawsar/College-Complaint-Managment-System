<?php 
    $regno = $_GET['regcheck'];
    $db = mysqli_connect('localhost','root','','ourproject');
    
?>
