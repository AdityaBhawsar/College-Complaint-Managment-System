<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		body{
			background-image: url("texture-wallpaper-58.jpg");
		      background-size: 50%;
		      box-shadow: inset 3px 10px 20px 5px rgba(0, 0, 0, .9);
		}
		.sarvesh{
			box-shadow:  3px 10px 20px 5px rgba(0, 0, 0, .9);
			height: 320px;
			width: 320px;
			margin-top: 50px;
			margin-left: 100px;
			position: absolute;
			background: url("IMG_20181003_233517_276-2.jpg");
			background-size: 100%;
		}
		.adi:hover{
			background: url("IMG_1114.jpg");
			background-size: 100%;
			box-shadow:  3px 10px 20px 5px rgba(0, 0, 0, .9);	
		}
		.sarvesh:hover{
			background: url("IMG_20181003_233517_276.jpg");
			background-size: 100%;
			box-shadow:  3px 10px 20px 5px rgba(0, 0, 0, .9);	
		}
		.vivek:hover{
			background: url("LRM_EXPORT_20180812_163939.jpg");
			background-size: 100%;
			box-shadow:  3px 10px 20px 5px rgba(0, 0, 0, .9);	
		}
		.adi{
			box-shadow:  3px 10px 20px 5px rgba(0, 0, 0, .9);
			height: 500px;
			width: 250px;
			margin-top: 300px;
			margin-left: 500px;
			position: absolute;
			background: url("IMG_1114-2.jpg");
			background-size: 100%;

		}
		.vivek{
			box-shadow:  3px 10px 20px 5px rgba(0, 0, 0, .9);
			height: 360px;
			width: 250px;
			margin-top: 50px;
			margin-left: 850px;
			position: absolute;
			background: url("LRM_EXPORT_20180812_163939-2.jpg");
			background-size: 100%;

		}
	</style>
</head>
<body>
	<!-- <img src="sarvesh.jpg (1 of 1).jpg" class="sarvesh"> -->
	<div class="sarvesh"></div>
	<div class="adi"></div>
	<div class="vivek"></div>
	
</body>
</html>